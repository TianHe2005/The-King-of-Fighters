﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 使用者 JSBattle.rc

#define IDC_MYICON                      2
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDC_FIGHTGAME                   109
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       135
#define IDB_BITMAP_KYOKUSANAGI          151
#define IDB_BITMAP1                     152
#define IDB_BITMAP_BG                   153
#define IDB_BITMAP_KULA                 154
#define IDR_BMP1                        161
#define IDB_BITMAP_HELP                 166
#define IDB_BITMAP_RETURN               167
#define IDB_BITMAP_RESTART              168
#define IDB_BITMAP_RESTORE              169
#define IDB_BITMAP_STAGE1               170
#define IDB_BITMAP_WATCHMODE            171
#define IDB_BITMAP_START                172
#define IDB_BITMAP_END                  173
#define IDB_BITMAP_HELP2                174
#define IDB_BITMAP_STAGE2               175
#define IDB_BITMAP_STAGE4               177
#define IDB_BITMAP_STAGE3               181
#define IDB_BITMAP_CONTINUE             182
#define IDB_BITMAP_DRUG1                183
#define IDB_BITMAP_DRUG2                184
#define IDB_BITMAP_DRUG3                185
#define IDB_BITMAP_KULA_S               186
#define IDB_BITMAP_KYOKUSANAGI_S        187
#define IDB_BITMAP_STAGE1_S             188
#define IDB_BITMAP_STAGE2_S             189
#define IDB_BITMAP_STAGE3_S             190
#define IDB_BITMAP_STAGE4_S             191
#define IDB_BITMAP_CHOOSE               192

// 新对象的下一组默认值
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NO_MFC					130
#define _APS_NEXT_RESOURCE_VALUE	129
#define _APS_NEXT_COMMAND_VALUE		32771
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		110
#endif
#endif
